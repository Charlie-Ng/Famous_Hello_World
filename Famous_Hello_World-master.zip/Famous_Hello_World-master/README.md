** Hello World **

A hello world project using pure famo.us JavaScript framework + JavsScript

Project Description:
Each letter in "Hello World!" is bound to a responsive grid and has its own transformation and a chaining transformation followed by.
Depending on the window size, grid will have 1 row if window is large enough, otherwise it will have 2 rows. Number of columns is the length of
"Hello World!".
"Hello World!" can be moved by mouse, touch scrolling, and mouse scrolling.
Colors of each letter keeps changing for 15 seconds to prevent overhead.
The project can be viewed in mobile devices.

# Famous_Hello_World
